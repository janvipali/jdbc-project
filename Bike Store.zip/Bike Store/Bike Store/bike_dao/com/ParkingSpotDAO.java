package bike_dao.com;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import dbconnection.com.DBConnection;
import modules.com.ParkingSpot;

public class ParkingSpotDAO {
    
    public void addParkingSpot(ParkingSpot spot) throws SQLException {
        String query = "INSERT INTO parking_spots (spot_number, is_occupied) VALUES (?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, spot.getSpotNumber());
            stmt.setBoolean(2, spot.isOccupied());
            stmt.executeUpdate();
        }
    }

    public ParkingSpot getParkingSpot(int spotId) throws SQLException {
        String query = "SELECT * FROM parking_spots WHERE spot_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, spotId);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return new ParkingSpot(rs.getInt("spot_id"), rs.getInt("spot_number"), rs.getBoolean("is_occupied"));
                }
            }
        }
        return null;
    }

    public void updateParkingSpot(ParkingSpot spot) throws SQLException {
        String query = "UPDATE parking_spots SET spot_number = ?, is_occupied = ? WHERE spot_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, spot.getSpotNumber());
            stmt.setBoolean(2, spot.isOccupied());
            stmt.setInt(3, spot.getSpotId());
            stmt.executeUpdate();
        }
    }

    public void deleteParkingSpot(int spotId) throws SQLException {
        String query = "DELETE FROM parking_spots WHERE spot_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, spotId);
            stmt.executeUpdate();
        }
    }
}
