package bike_dao.com;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import dbconnection.com.DBConnection;
import modules.com.Bike;

public class BikeDAO {
    
    public void addBike(Bike bike) throws SQLException {
        String query = "INSERT INTO bikes (bike_number, user_id, spot_id) VALUES (?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, bike.getBikeNumber());
            stmt.setInt(2, bike.getUserId());
            stmt.setInt(3, bike.getSpotId());
            stmt.executeUpdate();
        }
    }

    public Bike getBike(int bikeId) throws SQLException {
        String query = "SELECT * FROM bikes WHERE bike_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, bikeId);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return new Bike(rs.getInt("bike_id"), rs.getString("bike_number"), rs.getInt("user_id"), rs.getInt("spot_id"));
                }
            }
        }
        return null;
    }

    public void updateBike(Bike bike) throws SQLException {
        String query = "UPDATE bikes SET bike_number = ?, user_id = ?, spot_id = ? WHERE bike_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, bike.getBikeNumber());
            stmt.setInt(2, bike.getUserId());
            stmt.setInt(3, bike.getSpotId());
            stmt.setInt(4, bike.getBikeId());
            stmt.executeUpdate();
        }
    }

    public void deleteBike(int bikeId) throws SQLException {
        String query = "DELETE FROM bikes WHERE bike_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, bikeId);
            stmt.executeUpdate();
        }
    }
}
