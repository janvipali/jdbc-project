package modules.com;
public class ParkingSpot {
      private int spotId;
      private int spotNumber;
      private boolean isOccupied;
  
      public ParkingSpot(int spotId, int spotNumber, boolean isOccupied) {
          this.spotId = spotId;
          this.spotNumber = spotNumber;
          this.isOccupied = isOccupied;
      }
  
      // Getters and setters
      public int getSpotId() {
          return spotId;
      }
  
      public void setSpotId(int spotId) {
          this.spotId = spotId;
      }
  
      public int getSpotNumber() {
          return spotNumber;
      }
  
      public void setSpotNumber(int spotNumber) {
          this.spotNumber = spotNumber;
      }
  
      public boolean isOccupied() {
          return isOccupied;
      }
  
      public void setOccupied(boolean occupied) {
          isOccupied = occupied;
      }
  }
  