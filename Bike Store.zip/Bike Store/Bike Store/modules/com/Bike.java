package modules.com;
public class Bike {
      private int bikeId;
      private String bikeNumber;
      private int userId;
      private int spotId;
  
      public Bike(int bikeId, String bikeNumber, int userId, int spotId) {
          this.bikeId = bikeId;
          this.bikeNumber = bikeNumber;
          this.userId = userId;
          this.spotId = spotId;
      }
  
      // Getters and setters
      public int getBikeId() {
          return bikeId;
      }
  
      public void setBikeId(int bikeId) {
          this.bikeId = bikeId;
      }
  
      public String getBikeNumber() {
          return bikeNumber;
      }
  
      public void setBikeNumber(String bikeNumber) {
          this.bikeNumber = bikeNumber;
      }
  
      public int getUserId() {
          return userId;
      }
  
      public void setUserId(int userId) {
          this.userId = userId;
      }
  
      public int getSpotId() {
          return spotId;
      }
  
      public void setSpotId(int spotId) {
          this.spotId = spotId;
      }
  }
  