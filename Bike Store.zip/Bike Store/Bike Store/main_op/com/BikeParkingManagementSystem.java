package main_op.com;
import java.sql.SQLException;
import java.util.Scanner;

import bike_dao.com.BikeDAO;
import bike_dao.com.ParkingSpotDAO;
import bike_dao.com.UserDAO;
import modules.com.Bike;
import modules.com.ParkingSpot;
import modules.com.User;

public class BikeParkingManagementSystem {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        UserDAO userDAO = new UserDAO();
        BikeDAO bikeDAO = new BikeDAO();
        ParkingSpotDAO parkingSpotDAO = new ParkingSpotDAO();
        
        while (true) {
            System.out.println("1. Add User");
            System.out.println("2. Get User");
            System.out.println("3. Update User");
            System.out.println("4. Delete User");
            System.out.println("5. Add Bike");
            System.out.println("6. Get Bike");
            System.out.println("7. Update Bike");
            System.out.println("8. Delete Bike");
            System.out.println("9. Add Parking Spot");
            System.out.println("10. Get Parking Spot");
            System.out.println("11. Update Parking Spot");
            System.out.println("12. Delete Parking Spot");
            System.out.println("13. Exit");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            try {
                switch (choice) {
                    case 1:
                        System.out.print("Enter name: ");
                        String name = scanner.nextLine();
                        System.out.print("Enter email: ");
                        String email = scanner.nextLine();
                        User newUser = new User(0, name, email);
                        userDAO.addUser(newUser);
                        System.out.println("User added successfully.");
                        break;
                    case 2:
                        System.out.print("Enter user ID: ");
                        int userId = scanner.nextInt();
                        User user = userDAO.getUser(userId);
                        if (user != null) {
                            System.out.println("User ID: " + user.getUserId());
                            System.out.println("Name: " + user.getName());
                            System.out.println("Email: " + user.getEmail());

                        } else {
                            System.out.println("User not found.");
                        }
                        break;
                    case 3:
                        System.out.print("Enter user ID: ");
                        int updateUserId = scanner.nextInt();
                        scanner.nextLine(); // Consume newline
                        System.out.print("Enter new name: ");
                        String newName = scanner.nextLine();
                        System.out.print("Enter new email: ");
                        String newEmail = scanner.nextLine();
                        User updatedUser = new User(updateUserId, newName, newEmail);
                        userDAO.updateUser(updatedUser);
                        System.out.println("User updated successfully.");
                        break;
                    case 4:
                        System.out.print("Enter user ID: ");
                        int deleteUserId = scanner.nextInt();
                        userDAO.deleteUser(deleteUserId);
                        System.out.println("User deleted successfully.");
                        break;
                    case 5:
                        System.out.print("Enter bike number: ");
                        String bikeNumber = scanner.nextLine();
                        System.out.print("Enter user ID: ");
                        int userBikeId = scanner.nextInt();
                        System.out.print("Enter spot ID: ");
                        int spotId = scanner.nextInt();
                        Bike newBike = new Bike(0, bikeNumber, userBikeId, spotId);
                        bikeDAO.addBike(newBike);
                        System.out.println("Bike added successfully.");
                        break;
                    case 6:
                        System.out.print("Enter bike ID: ");
                        int bikeId = scanner.nextInt();
                        Bike bike = bikeDAO.getBike(bikeId);
                        if (bike != null) {
                            System.out.println("Bike ID: " + bike.getBikeId());
                            System.out.println("Bike Number: " + bike.getBikeNumber());
                            System.out.println("User ID: " + bike.getUserId());
                            System.out.println("Spot ID: " + bike.getSpotId());
                        } else {
                            System.out.println("Bike not found.");
                        }
                        break;
                    case 7:
                        System.out.print("Enter bike ID: ");
                        int updateBikeId = scanner.nextInt();
                        scanner.nextLine(); // Consume newline
                        System.out.print("Enter new bike number: ");
                        String newBikeNumber = scanner.nextLine();
                        System.out.print("Enter new user ID: ");
                        int newUserId = scanner.nextInt();
                        System.out.print("Enter new spot ID: ");
                        int newSpotId = scanner.nextInt();
                        Bike updatedBike = new Bike(updateBikeId, newBikeNumber, newUserId, newSpotId);
                        bikeDAO.updateBike(updatedBike);
                        System.out.println("Bike updated successfully.");
                        break;
                    case 8:
                        System.out.print("Enter bike ID: ");
                        int deleteBikeId = scanner.nextInt();
                        bikeDAO.deleteBike(deleteBikeId);
                        System.out.println("Bike deleted successfully.");
                        break;
                    case 9:
                        System.out.print("Enter spot number: ");
                        int spotNumber = scanner.nextInt();
                        System.out.print("Is occupied (true/false): ");
                        boolean isOccupied = scanner.nextBoolean();
                        ParkingSpot newSpot = new ParkingSpot(0, spotNumber, isOccupied);
                        parkingSpotDAO.addParkingSpot(newSpot);
                        System.out.println("Parking spot added successfully.");
                        break;
                    case 10:
                        System.out.print("Enter spot ID: ");
                        int spotIdGet = scanner.nextInt();
                        ParkingSpot spot = parkingSpotDAO.getParkingSpot(spotIdGet);
                        if (spot != null) {
                            System.out.println("Spot ID: " + spot.getSpotId());
                            System.out.println("Spot Number: " + spot.getSpotNumber());
                            System.out.println("Is Occupied: " + spot.isOccupied());
                        } else {
                            System.out.println("Parking spot not found.");
                        }
                        break;
                    case 11:
                        System.out.print("Enter spot ID: ");
                        int updateSpotId = scanner.nextInt();
                        System.out.print("Enter new spot number: ");
                        int newSpotNumber = scanner.nextInt();
                        System.out.print("Is occupied (true/false): ");
                        boolean newIsOccupied = scanner.nextBoolean();
                        ParkingSpot updatedSpot = new ParkingSpot(updateSpotId, newSpotNumber, newIsOccupied);
                        parkingSpotDAO.updateParkingSpot(updatedSpot);
                        System.out.println("Parking spot updated successfully.");
                        break;
                    case 12:
                        System.out.print("Enter spot ID: ");
                        int deleteSpotId = scanner.nextInt();
                        parkingSpotDAO.deleteParkingSpot(deleteSpotId);
                        System.out.println("Parking spot deleted successfully.");
                        break;
                    case 13:
                        System.out.println("Exiting...");
                        scanner.close();
                        return;
                    default:
                        System.out.println("Invalid choice. Please try again.");
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}
